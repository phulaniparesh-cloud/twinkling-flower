import turtle
import math
import random
import time

def get_shape_coords(a):
    """
    Returns (x, y) for a 6-petal flower with heart-shaped clefts 
    and a defined central circular boundary.
    """
    num_petals = 6
    sector = 2 * math.pi / num_petals
    
    # Localize angle to the current petal's center (-pi/6 to pi/6)
    phi = (a + sector/2) % sector - sector/2
    
    # Normalize u to range [-1, 1] across the petal
    u = phi / (sector / 2)  
    
    # Base circle radius = 5
    # Lobe amplitude = 11 (max extent)
    # Cleft dip = -5 * exp(-15 * u**2) pulls the tip inward to form the heart cleft
    r = 5 + 11 * math.cos(u * math.pi / 2) - 5 * math.exp(-15 * u**2)
    
    x = r * math.cos(a)
    y = r * math.sin(a)
    return x, y

def get_evenly_spaced_angles(num_points):
    """
    Approximates the curve to find angles that result in evenly 
    spaced points along the flower's perimeter based on arc length.
    """
    steps = 2000
    angles = [i * (math.pi * 2) / steps for i in range(steps)]
    
    distances = [0.0]
    for i in range(1, steps):
        x1, y1 = get_shape_coords(angles[i-1])
        x2, y2 = get_shape_coords(angles[i])
        distances.append(distances[-1] + math.hypot(x2 - x1, y2 - y1))
        
    total_length = distances[-1]
    target_spacing = total_length / num_points
    
    a_vals = []
    current_target = 0.0
    
    for i in range(steps - 1):
        while distances[i] <= current_target < distances[i+1]:
            fraction = (current_target - distances[i]) / (distances[i+1] - distances[i])
            a_vals.append(angles[i] + fraction * (angles[i+1] - angles[i]))
            current_target += target_spacing
            if len(a_vals) == num_points:
                return a_vals
    return a_vals

def draw_flower(t, c):
    h = t.heading()
    t.penup()
    for _ in range(5):
        t.forward(4)
        t.dot(5, c)
        t.backward(4)
        t.right(72)
    t.dot(4, "white")
    t.setheading(h)

def draw_inner_shape(t, colors, a_vals):
    t.penup()
    for a in a_vals[::4]:
        bx, by = get_shape_coords(a)
        t.goto(bx * 2.5, by * 2.5)
        draw_flower(t, random.choice(colors))

def draw_curve(t, sx, sy, ex, ey, bend):
    dx = ex - sx
    dy = ey - sy
    mx = (sx + ex) / 2
    my = (sy + ey) / 2
    
    cx = mx - dy * bend
    cy = my + dx * bend
    
    t.penup()
    t.goto(sx, sy)
    t.pendown()
    
    for i in range(1, 7):
        st = i / 6
        nx = ((1 - st)**2) * sx + 2 * (1 - st) * st * cx + (st**2) * ex
        ny = ((1 - st)**2) * sy + 2 * (1 - st) * st * cy + (st**2) * ey
        t.goto(nx, ny)

screen = turtle.Screen()
screen.bgcolor('black')
screen.title("Twinkling Flower")

screen.tracer(2) 

t = turtle.Turtle()
t.speed(0) 
t.hideturtle()

colors = ['red', 'blue', 'lime', 'yellow', 'cyan', 'magenta', 'pink', 'orange', 'violet']
num_lines = 120

a_vals = get_evenly_spaced_angles(num_lines)

draw_inner_shape(t, colors, a_vals)

for a in a_vals:
    bx, by = get_shape_coords(a)
    
    ex = bx * 15
    ey = by * 15
    
    sx = bx * 2.5
    sy = by * 2.5
    
    c = random.choice(colors)
    t.color(c)
    
    draw_curve(t, sx, sy, ex, ey, 0.2)
    draw_flower(t, c)

screen.update() 
time.sleep(1)   

screen.tracer(0) 

try:
    while True:
        t.clear()
        
        draw_inner_shape(t, colors, a_vals)
        
        for a in a_vals:
            bx, by = get_shape_coords(a)
            
            ex = bx * 15
            ey = by * 15
            
            sx = bx * 2.5
            sy = by * 2.5
            
            c = random.choice(colors)
            t.color(c)
            
            draw_curve(t, sx, sy, ex, ey, 0.2)
            draw_flower(t, c)
            
        screen.update()
        time.sleep(0.15)
        
except turtle.Terminator:
    pass
